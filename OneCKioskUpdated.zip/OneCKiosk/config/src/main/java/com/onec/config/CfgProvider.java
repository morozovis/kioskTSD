package com.onec.config;

import android.content.*;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;

public class CfgProvider extends ContentProvider {
    @Override public boolean onCreate() { return true; }
    @Override public Cursor query(Uri u, String[] p, String s, String[] a, String o) {
        SharedPreferences sp = getContext().getSharedPreferences("c", Context.MODE_PRIVATE);
        MatrixCursor c = new MatrixCursor(new String[]{"url", "nokb", "keepon", "focus"});
        c.addRow(new Object[]{sp.getString("url", ""), sp.getBoolean("nokb", true) ? 1 : 0, sp.getBoolean("keepon", true) ? 1 : 0, sp.getString("focus", "")});
        return c;
    }
    @Override public String getType(Uri u) { return "vnd.android.cursor.item/cfg"; }
    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] a) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
