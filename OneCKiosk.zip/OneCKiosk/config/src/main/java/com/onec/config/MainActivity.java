package com.onec.config;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.*;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        SharedPreferences sp = getSharedPreferences("c", MODE_PRIVATE);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(32, 32, 32, 32);
        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        setContentView(sv);

        TextView t = new TextView(this);
        t.setText("Адрес веб-клиента 1С");
        t.setTextSize(18);
        l.addView(t);
        EditText url = new EditText(this);
        url.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        url.setSingleLine(true);
        url.setHint("https://server/base/ru_RU/");
        url.setText(sp.getString("url", ""));
        l.addView(url, new ViewGroup.LayoutParams(-1, -2));

        CheckBox nokb = new CheckBox(this);
        nokb.setText("Не показывать экранную клавиатуру в просмотрщике");
        nokb.setChecked(sp.getBoolean("nokb", true));
        l.addView(nokb);
        CheckBox keep = new CheckBox(this);
        keep.setText("Не гасить экран");
        keep.setChecked(sp.getBoolean("keepon", true));
        l.addView(keep);

        Button save = new Button(this);
        save.setText("Сохранить и открыть");
        l.addView(save);
        save.setOnClickListener(v -> {
            String u = url.getText().toString().trim();
            if (!u.isEmpty() && !u.contains("://")) u = "https://" + u;
            sp.edit().putString("url", u).putBoolean("nokb", nokb.isChecked()).putBoolean("keepon", keep.isChecked()).apply();
            Intent i = getPackageManager().getLaunchIntentForPackage("com.onec.viewer");
            if (i != null) startActivity(i);
            else Toast.makeText(this, "Сохранено. Просмотрщик не установлен", Toast.LENGTH_LONG).show();
        });
    }
}
