package com.onec.viewer;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.*;

public class MainActivity extends Activity {
    static final Uri CFG = Uri.parse("content://com.onec.config.provider/cfg");

    /** WebView, который не вызывает экранную клавиатуру (физические клавиши и сканер работают). */
    class KWebView extends WebView {
        KWebView(Context c) { super(c); }
        @Override public boolean onCheckIsTextEditor() { return noKb ? false : super.onCheckIsTextEditor(); }
        @Override public android.view.inputmethod.InputConnection onCreateInputConnection(android.view.inputmethod.EditorInfo o) {
            return noKb ? null : super.onCreateInputConnection(o);
        }
    }

    static final String NOKB_JS = "(function(){if(window.__nk)return;window.__nk=1;"
        + "function m(t){if(t&&(t.tagName=='INPUT'||t.tagName=='TEXTAREA'||t.isContentEditable))t.setAttribute('inputmode','none');}"
        + "function f(e){m(e.target);}"
        + "['focusin','touchstart','mousedown'].forEach(function(n){document.addEventListener(n,f,true);});"
        + "function all(){document.querySelectorAll('input,textarea,[contenteditable]').forEach(m);}"
        + "all();new MutationObserver(all).observe(document.documentElement,{childList:true,subtree:true});})();";

    void hideKb() {
        android.view.inputmethod.InputMethodManager im = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(web.getWindowToken(), 0);
    }

    KWebView web;
    SharedPreferences sp;
    String url = "", loadedUrl = null;
    boolean noKb = true, keepOn = true;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("v", MODE_PRIVATE);
        readCfg();
        web = new KWebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(false);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String u, Bitmap f) { if (noKb) v.evaluateJavascript(NOKB_JS, null); }
            @Override public void onPageFinished(WebView v, String u) { saveCookies(u); if (noKb) v.evaluateJavascript(NOKB_JS, null); }
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (!r.isForMainFrame()) return;
                String u = url.replace("'", "");
                v.loadDataWithBaseURL(u, "<meta name=viewport content='width=device-width'><body style='font:22px sans-serif;padding:24px'>"
                    + "<h2>Нет связи с сервером</h2><button style='font-size:24px;padding:14px' onclick=\"location.replace('" + u + "')\">Повторить</button>",
                    "text/html", "utf-8", u);
            }
        });
        if (b != null) web.restoreState(b);
    }

    void readCfg() {
        try (Cursor c = getContentResolver().query(CFG, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                sp.edit().putString("url", c.getString(0)).putBoolean("nokb", c.getInt(1) == 1)
                    .putBoolean("keepon", c.getInt(2) == 1).apply();
            }
        } catch (Exception ignored) {}
        url = sp.getString("url", "");
        noKb = sp.getBoolean("nokb", true);
        keepOn = sp.getBoolean("keepon", true);
    }

    void restoreCookies() {
        if (url.isEmpty()) return;
        CookieManager cm = CookieManager.getInstance();
        String saved = sp.getString("cookies", null);
        if (saved == null || !saved.startsWith(origin(url))) return;
        String have = cm.getCookie(url);
        have = have == null ? "" : have;
        boolean sec = url.startsWith("https");
        String[] parts = saved.substring(origin(url).length()).split(";");
        for (String kv : parts) {
            kv = kv.trim();
            int i = kv.indexOf('=');
            if (i <= 0) continue;
            if (have.contains(kv.substring(0, i + 1))) continue; // уже есть - не трогаем
            cm.setCookie(origin(url), kv + "; Path=/; Max-Age=31536000" + (sec ? "; Secure" : ""));
        }
        cm.flush();
    }

    void saveCookies(String u) {
        if (u == null || !u.startsWith("http")) return;
        CookieManager cm = CookieManager.getInstance();
        String c = cm.getCookie(u);
        if (c != null) sp.edit().putString("cookies", origin(u) + c).apply();
        cm.flush();
    }

    static String origin(String u) {
        Uri p = Uri.parse(u);
        return p.getScheme() + "://" + p.getAuthority();
    }

    @Override protected void onResume() {
        super.onResume();
        web.onResume();
        readCfg();
        if (keepOn) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (noKb) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
        }
        if (url.isEmpty()) {
            web.loadData("<meta name=viewport content='width=device-width'><body style='font:22px sans-serif;padding:24px'>"
                + "<h2>Адрес не задан</h2>Откройте приложение «1C Config» и укажите ссылку.", "text/html", "utf-8");
            loadedUrl = null;
        } else if (!url.equals(loadedUrl)) {
            restoreCookies();
            web.loadUrl(url);
            loadedUrl = url;
        }
    }

    @Override protected void onPause() {
        saveCookies(web.getUrl());
        super.onPause();
    }

    @Override protected void onStop() {
        saveCookies(web.getUrl());
        super.onStop();
    }

    @Override protected void onSaveInstanceState(Bundle o) {
        super.onSaveInstanceState(o);
        web.saveState(o);
    }

    @Override public boolean onKeyDown(int k, KeyEvent e) {
        if (k == KeyEvent.KEYCODE_BACK && web.canGoBack()) { web.goBack(); return true; }
        if (k == KeyEvent.KEYCODE_BACK) return true; // не закрываем киоск
        return super.onKeyDown(k, e);
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }
}
